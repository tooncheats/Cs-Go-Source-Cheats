# 🔥 Hammer CS:GO Hacks
<img src="https://flat.badgen.net/badge/VAC/Undetected./green?icon=terminal">
A few CS:GO hacks made with the classic "write memory" logic. Most of its features are adjustable and will be constantly updated.

You can download executable from [here](https://github.com/barbarbar338/hammer-csgo-hack/releases).

# ✨ Features
- 🎯 Aim Lock
- 🔈 Silent Aim
- 🐇 Bunny Hop
- 🌠 Glow Hack
- 🎆 Charm Hack
- ✨ No Flash
- 🗺️ Radar Positions
- 🔫 Trigger Bot
- 🥽 FOV
- 🐱‍👤 Anti Recoil
- 🏆 Rank Revealer
- 🎀 Skin changer (For some reason skin changer is not working, will be fixed soon!)

# 🎈 Starting Hacks
- Edit `config.yaml` (The settings it contains are recommended settings.)
- Edit `skins.txt` (For some reason skin changer is not working)
- Run CS:GO
- Run `hammer.exe`

# 🔧 Known Bugs
- When the Skin Changer is on, other hacks not working.

# 🛑 VAC
I have been using the cheat aggressively since 10.01.2021 and I haven't had a VAC ban yet. However, my friend showed more than me and get reports of about 10 people at the same time and he was banned. As you can see, the CS:GO cheat protection system is quite simple but brutal. Nevertheless, use it at the risk of VAC banning. I do not accept any liability if you are VAC banned. Use at your own risk.

# 🧨 Build your own instance
I recommend you to use my builds in the [Releases](https://github.com/barbarbar338/hammer-csgo-hack/releases) section, but you can also create your own ".exe" file by following the steps below.
- Download repository files
- Run `pip intall -r requirements.txt`
- Run `python build.py`
- Follow starting instructions

# 🧛‍♀️ Contributing
Feel free to use GitHub's features. (Don't forget to run `python scripts/format.py` before creating a PR)
